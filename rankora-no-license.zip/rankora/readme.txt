=== Rankora ===
Contributors: rankora
Tags: seo, ai, content
Requires at least: 5.8
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.1.0
License: Proprietary
License URI: N/A

== Description ==
Rankora is an AI-powered content and SEO plugin.

== Installation ==
1. Upload the plugin ZIP via WordPress Admin > Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Configure your OpenAI API key in Rankora settings.

== Frequently Asked Questions ==
= How do I set the post language? =
Edit a post and use the "Post Language (SBAIG)" box in the sidebar.

== Changelog ==
= 1.1.0 =
* Removed license activation requirement.

= 1.0.1 =
* Added per-post language selector (all WordPress locales).

= 1.0.0 =
* Initial release.
