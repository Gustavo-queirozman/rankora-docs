<?php
/**
 * Plugin Name: Rankora
 * Description: Rankora is an AI-powered content and SEO plugin that helps you create high-quality blog posts optimized for TOFU, MOFU, and BOFU strategies. It automatically generates SEO-ready content with meta tags, Open Graph, Twitter Cards, structured data (JSON-LD), and an integrated XML sitemap — all in one lightweight solution.
 * Version: 1.1.0
 * Author: gustavo_queirozman
 * Text Domain: sbaig
 */

defined('ABSPATH') || exit;

class Rankora {

    // Settings
    const OPTION_KEY_OPENAI   = 'sbaig_openai_key';
    const OPTION_ENABLE_SEO   = 'sbaig_enable_seo';
    const OPTION_ENABLE_SCHEMA= 'sbaig_enable_schema';
    const OPTION_ENABLE_SITEMAP = 'sbaig_enable_sitemap';
    const OPTION_DEFAULT_OG_IMAGE = 'sbaig_default_og_image';

    // Licensing (Lemon Squeezy)
    const OPTION_LICENSE_KEY     = 'rankora_ls_license_key';
    const OPTION_LICENSE_STATUS  = 'rankora_ls_license_status';
    const OPTION_LICENSE_INSTANCE= 'rankora_ls_instance_id';
    const OPTION_LICENSE_LASTCHK = 'rankora_ls_last_check';

    // Post meta keys
    const META_CONTENT_TYPE   = 'blog_content_type';
    
    const META_POST_LANGUAGE = '_sbaig_post_language';
const META_SEO_TITLE      = '_sbaig_seo_title';
    const META_SEO_DESC       = '_sbaig_seo_desc';
    const META_FOCUS_KW       = '_sbaig_focus_kw';
    const META_CANONICAL      = '_sbaig_canonical';
    const META_OG_IMAGE       = '_sbaig_og_image';
    const META_NOINDEX        = '_sbaig_noindex';
    const META_FAQ_JSON       = '_sbaig_faq_json';

    // Nonces
    const NONCE_GEN   = 'sbaig_generate_nonce';
    const NONCE_MB    = 'sbaig_metabox_nonce';
    const NONCE_SEO_MB= 'sbaig_seo_metabox_nonce';

    // Sitemap
    const SITEMAP_QUERY_VAR = 'sbaig_sitemap';

    public function __construct() {
        add_action('plugins_loaded', [$this, 'load_textdomain']);

        // Admin
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_post_sbaig_generate_post', [$this, 'handle_generate_post']);
        add_action('admin_notices', [$this, 'admin_notices']);

        add_action('add_meta_boxes', [$this, 'add_metaboxes']);
        add_action('save_post', [$this, 'save_metaboxes'], 10, 2);

        // Front-end SEO
        add_action('wp_head', [$this, 'output_seo_meta'], 1);

        // Sitemap route
        add_action('init', [$this, 'register_sitemap_route']);
        add_filter('query_vars', [$this, 'register_query_vars']);
        add_action('template_redirect', [$this, 'maybe_render_sitemap']);

        // Activation / deactivation
        register_activation_hook(__FILE__, [__CLASS__, 'on_activate']);
        register_deactivation_hook(__FILE__, [__CLASS__, 'on_deactivate']);
    }

    public static function on_activate() {
        $self = new self();
        $self->register_sitemap_route();
        flush_rewrite_rules();
    }

    public static function on_deactivate() {
        flush_rewrite_rules();
    }

    public function load_textdomain() {
        load_plugin_textdomain('sbaig', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    /* =========================
     * Admin UI
     * ========================= */

    public function admin_menu() {
        add_submenu_page(
            'tools.php',
            __('Rankora', 'sbaig'),
            __('Rankora', 'sbaig'),
            'manage_options',
            'sbaig-generator',
            [$this, 'generator_page']
        );


        add_options_page(
            __('Rankora Settings', 'sbaig'),
            __('Rankora', 'sbaig'),
            'manage_options',
            'sbaig-settings',
            [$this, 'settings_page']
        );
    }

    public function register_settings() {
        register_setting('sbaig_settings', self::OPTION_KEY_OPENAI, [
            'type'              => 'string',
            'sanitize_callback' => [$this, 'sanitize_api_key'],
            'default'           => '',
        ]);

        register_setting('sbaig_settings', self::OPTION_ENABLE_SEO, [
            'type'              => 'boolean',
            'sanitize_callback' => function($v) { return (bool) $v; },
            'default'           => true,
        ]);

        register_setting('sbaig_settings', self::OPTION_ENABLE_SCHEMA, [
            'type'              => 'boolean',
            'sanitize_callback' => function($v) { return (bool) $v; },
            'default'           => true,
        ]);

        register_setting('sbaig_settings', self::OPTION_ENABLE_SITEMAP, [
            'type'              => 'boolean',
            'sanitize_callback' => function($v) { return (bool) $v; },
            'default'           => true,
        ]);

        register_setting('sbaig_settings', self::OPTION_DEFAULT_OG_IMAGE, [
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        ]);
    }

    public function sanitize_api_key($value) {
        $value = is_string($value) ? trim($value) : '';
        // Remove espaços e caracteres invisíveis
        $value = preg_replace('/\s+/', '', $value);
        return $value;
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to access this page.', 'sbaig'));
        }

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Rankora – Settings', 'sbaig') . '</h1>';
        echo '<form method="post" action="options.php">';
        settings_fields('sbaig_settings');
        do_settings_sections('sbaig_settings');

        $openai = esc_attr(get_option(self::OPTION_KEY_OPENAI, ''));
        $enable_seo = (bool) get_option(self::OPTION_ENABLE_SEO, true);
        $enable_schema = (bool) get_option(self::OPTION_ENABLE_SCHEMA, true);
        $enable_sitemap = (bool) get_option(self::OPTION_ENABLE_SITEMAP, true);
        $default_og = esc_url(get_option(self::OPTION_DEFAULT_OG_IMAGE, ''));

        echo '<table class="form-table" role="presentation">';

        echo '<tr><th scope="row"><label for="sbaig_openai_key">' . esc_html__('OpenAI API Key', 'sbaig') . '</label></th><td>';
        echo '<input id="sbaig_openai_key" type="password" name="' . esc_attr(self::OPTION_KEY_OPENAI) . '" value="' . $openai . '" style="width: 420px;" autocomplete="off" />';
        echo '<p class="description">' . esc_html__('Required to generate posts and SEO fields.', 'sbaig') . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__('Enable SEO meta tags', 'sbaig') . '</th><td>';
        echo '<label><input type="checkbox" name="' . esc_attr(self::OPTION_ENABLE_SEO) . '" value="1" ' . checked(true, $enable_seo, false) . ' /> ' . esc_html__('Output title/description, canonical, Open Graph and Twitter Cards.', 'sbaig') . '</label>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__('Enable JSON-LD schema', 'sbaig') . '</th><td>';
        echo '<label><input type="checkbox" name="' . esc_attr(self::OPTION_ENABLE_SCHEMA) . '" value="1" ' . checked(true, $enable_schema, false) . ' /> ' . esc_html__('Output Article + optional FAQ schema on single posts.', 'sbaig') . '</label>';
        echo '</td></tr>';

        $sitemap_url = esc_url(home_url('/sbaig-sitemap.xml'));
        echo '<tr><th scope="row">' . esc_html__('Enable XML sitemap', 'sbaig') . '</th><td>';
        echo '<label><input type="checkbox" name="' . esc_attr(self::OPTION_ENABLE_SITEMAP) . '" value="1" ' . checked(true, $enable_sitemap, false) . ' /> ' . esc_html__('Expose /sbaig-sitemap.xml (posts only).', 'sbaig') . '</label>';
        echo '<p class="description">' . sprintf(esc_html__('Sitemap URL: %s', 'sbaig'), '<code>' . $sitemap_url . '</code>') . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="sbaig_default_og_image">' . esc_html__('Default Open Graph Image URL', 'sbaig') . '</label></th><td>';
        echo '<input id="sbaig_default_og_image" type="url" name="' . esc_attr(self::OPTION_DEFAULT_OG_IMAGE) . '" value="' . $default_og . '" style="width: 420px;" placeholder="https://example.com/og-default.jpg" />';
        echo '<p class="description">' . esc_html__('Used when a post has no featured image and no custom OG image set.', 'sbaig') . '</p>';
        echo '</td></tr>';

        echo '</table>';

        submit_button(__('Save Settings', 'sbaig'));
        echo '</form></div>';
    }

    public function generator_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to access this page.', 'sbaig'));
        }

        $action_url = esc_url(admin_url('admin-post.php'));

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Rankora', 'sbaig') . '</h1>';
        echo '<p>' . esc_html__('Generate a blog post + SEO fields (meta title/description, slug, tags, and optional FAQ).', 'sbaig') . '</p>';


        echo '<form method="post" action="' . $action_url . '">';
        echo '<input type="hidden" name="action" value="sbaig_generate_post" />';
        wp_nonce_field(self::NONCE_GEN, self::NONCE_GEN);

        echo '<table class="form-table" role="presentation">';

        echo '<tr><th scope="row">' . esc_html__('Post Title', 'sbaig') . '</th><td>';
        echo '<input type="text" name="title" required style="width:420px" />';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__('Blog Content Type', 'sbaig') . '</th><td>';
        echo '<select name="content_type" required>';
        echo '<option value="tofu">' . esc_html__('TOFU – Educational / SEO', 'sbaig') . '</option>';
        echo '<option value="mofu">' . esc_html__('MOFU – Consideration', 'sbaig') . '</option>';
        echo '<option value="bofu">' . esc_html__('BOFU – Conversion', 'sbaig') . '</option>';
        echo '</select>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__('Status', 'sbaig') . '</th><td>';
        echo '<select name="status">';
        echo '<option value="draft">' . esc_html__('Draft', 'sbaig') . '</option>';
        echo '<option value="publish">' . esc_html__('Publish', 'sbaig') . '</option>';
        echo '</select>';
        echo '</td></tr>';

        echo '</table>';

        submit_button(__('Generate Post', 'sbaig'));

        echo '</form></div>';
    }

    public function admin_notices() {
        if (!is_admin()) return;

        // Show notice on generator page only
        if (empty($_GET['page']) || $_GET['page'] !== 'sbaig-generator') return;
        if (empty($_GET['sbaig_notice']) || empty($_GET['sbaig_msg'])) return;

        $type = sanitize_text_field(wp_unslash($_GET['sbaig_notice']));
        $msg  = sanitize_text_field(rawurldecode(wp_unslash($_GET['sbaig_msg'])));
        $edit = !empty($_GET['sbaig_edit']) ? esc_url_raw(rawurldecode(wp_unslash($_GET['sbaig_edit']))) : '';

        $class = 'notice notice-info';
        if ($type === 'success') $class = 'notice notice-success';
        if ($type === 'error')   $class = 'notice notice-error';

        echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($msg);

        if (!empty($edit)) {
            echo ' <a href="' . esc_url($edit) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Edit post', 'sbaig') . '</a>';
        }

        echo '</p></div>';
    }

    private function redirect_with_notice($type, $message, $edit_link = '') {
        $url = add_query_arg([
            'page'          => 'sbaig-generator',
            'sbaig_notice'  => $type,
            'sbaig_msg'     => rawurlencode($message),
            'sbaig_edit'    => rawurlencode($edit_link),
        ], admin_url('tools.php'));

        wp_safe_redirect($url);
        exit;
    }

    /* =========================
     * Post generation (OpenAI)
     * ========================= */

    public function handle_generate_post() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to perform this action.', 'sbaig'));
        }

        if (!isset($_POST[self::NONCE_GEN]) || !wp_verify_nonce($_POST[self::NONCE_GEN], self::NONCE_GEN)) {
            $this->redirect_with_notice('error', __('Security check failed (nonce).', 'sbaig'));
        }

        $title  = sanitize_text_field($_POST['title'] ?? '');
        $type   = sanitize_text_field($_POST['content_type'] ?? 'tofu');
        $status = sanitize_text_field($_POST['status'] ?? 'draft');

        $allowed_types  = ['tofu', 'mofu', 'bofu'];
        $allowed_status = ['draft', 'publish'];

        if (empty($title)) {
            $this->redirect_with_notice('error', __('Please provide a post title.', 'sbaig'));
        }
        if (!in_array($type, $allowed_types, true)) {
            $type = 'tofu';
        }
        if (!in_array($status, $allowed_status, true)) {
            $status = 'draft';
        }


        $api_key = get_option(self::OPTION_KEY_OPENAI);
        if (!$api_key) {
            $this->redirect_with_notice('error', __('Missing OpenAI API Key. Please configure it in Settings.', 'sbaig'));
        }

        $bundle = $this->call_openai_and_get_bundle($api_key, $title, $type);
        if (is_wp_error($bundle)) {
            $this->redirect_with_notice('error', sprintf(
                __('OpenAI request failed: %s', 'sbaig'),
                $bundle->get_error_message()
            ));
        }

        $content_html = (string) ($bundle['content_html'] ?? '');
        if (empty($content_html)) {
            $this->redirect_with_notice('error', __('OpenAI returned empty content.', 'sbaig'));
        }

        $slug = !empty($bundle['slug']) ? sanitize_title($bundle['slug']) : sanitize_title($title);
        $seo_title = isset($bundle['meta_title']) ? sanitize_text_field($bundle['meta_title']) : '';
        $seo_desc  = isset($bundle['meta_description']) ? sanitize_textarea_field($bundle['meta_description']) : '';
        $focus_kw  = isset($bundle['focus_keyword']) ? sanitize_text_field($bundle['focus_keyword']) : '';

        // Insert post
        $post_arr = [
            'post_title'   => $title,
            'post_content' => wp_kses_post($content_html),
            'post_status'  => $status,
            'post_type'    => 'post',
            'post_name'    => $slug,
        ];

        // Use meta description as excerpt if provided
        if (!empty($seo_desc)) {
            $post_arr['post_excerpt'] = $seo_desc;
        }

        $post_id = wp_insert_post($post_arr, true);

        if (is_wp_error($post_id)) {
            $this->redirect_with_notice('error', sprintf(
                __('Failed to create post: %s', 'sbaig'),
                $post_id->get_error_message()
            ));
        }

        // Content type meta
        update_post_meta($post_id, self::META_CONTENT_TYPE, $type);

        // SEO meta
        if (!empty($seo_title)) update_post_meta($post_id, self::META_SEO_TITLE, $seo_title);
        if (!empty($seo_desc))  update_post_meta($post_id, self::META_SEO_DESC, $seo_desc);
        if (!empty($focus_kw))  update_post_meta($post_id, self::META_FOCUS_KW, $focus_kw);

        if (!empty($bundle['canonical'])) {
            update_post_meta($post_id, self::META_CANONICAL, esc_url_raw($bundle['canonical']));
        }

        if (!empty($bundle['og_image'])) {
            update_post_meta($post_id, self::META_OG_IMAGE, esc_url_raw($bundle['og_image']));
        }

        if (!empty($bundle['noindex'])) {
            update_post_meta($post_id, self::META_NOINDEX, $bundle['noindex'] ? '1' : '0');
        }

        if (!empty($bundle['faq']) && is_array($bundle['faq'])) {
            // Store as JSON for schema
            update_post_meta($post_id, self::META_FAQ_JSON, wp_json_encode($bundle['faq']));
        }

        // Tags
        if (!empty($bundle['tags']) && is_array($bundle['tags'])) {
            $tags = array_filter(array_map('sanitize_text_field', $bundle['tags']));
            if (!empty($tags)) {
                wp_set_post_terms($post_id, $tags, 'post_tag', false);
            }
        }

        // Link direto de edição
        $edit_link = get_edit_post_link($post_id, 'raw');
        $this->redirect_with_notice('success', __('Post generated successfully!', 'sbaig'), $edit_link);
    }

    private function call_openai_and_get_bundle($api_key, $title, $type) {
        $type_up = strtoupper($type);

        $prompt = sprintf(
            "You are an expert SaaS content writer and SEO specialist.\n" .
            "Create a WordPress-ready blog post as HTML.\n\n" .
            "Funnel stage: %s\n" .
            "Title: %s\n\n" .
            "Requirements:\n" .
            "- Natural, helpful tone; no fluff.\n" .
            "- Use <h2>, <h3>, lists, and short paragraphs.\n" .
            "- Include a concise conclusion.\n" .
            "- Do NOT use Markdown.\n" .
            "- If it makes sense, include a short FAQ (2-5 Q&As) at the end.\n\n" .
            "Output STRICT JSON ONLY with these keys:\n" .
            "{\n" .
            '  "content_html": "<p>...</p>",' . "\n" .
            '  "meta_title": "Max 60 chars",' . "\n" .
            '  "meta_description": "Max 155 chars",' . "\n" .
            '  "focus_keyword": "1 main keyword phrase",' . "\n" .
            '  "slug": "url-friendly-slug",' . "\n" .
            '  "tags": ["tag1","tag2","tag3"],' . "\n" .
            '  "faq": [{"q":"...","a":"..." }]' . "\n" .
            "}\n" .
            "Rules:\n" .
            "- content_html must be valid HTML and should NOT include <html>, <head>, or <body>.\n" .
            "- faq is optional (omit or empty array if not used).\n",
            $type_up,
            $title
        );

        $response = wp_remote_post('https://api.openai.com/v1/responses', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json; charset=utf-8',
            ],
            'timeout' => 90,
            'body'    => wp_json_encode([
                'model' => 'gpt-4.1-mini',
                'input' => $prompt,
            ]),
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code < 200 || $code >= 300) {
            error_log('[SBAIG] OpenAI HTTP ' . $code . ' body: ' . $body);
            return new WP_Error('sbaig_openai_http', 'OpenAI HTTP error: ' . $code);
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            error_log('[SBAIG] Invalid JSON from OpenAI API: ' . $body);
            return new WP_Error('sbaig_openai_json', 'Invalid JSON from OpenAI (see debug.log).');
        }

        // Responses API usually returns "output_text"
        $text = '';
        if (!empty($data['output_text']) && is_string($data['output_text'])) {
            $text = $data['output_text'];
        } elseif (!empty($data['output']) && is_array($data['output'])) {
            // Fallback: search for text chunks
            foreach ($data['output'] as $item) {
                if (!is_array($item) || empty($item['content']) || !is_array($item['content'])) continue;
                foreach ($item['content'] as $c) {
                    if (is_array($c) && isset($c['text']) && is_string($c['text'])) {
                        $text .= $c['text'];
                    }
                }
            }
        }

        $text = trim((string) $text);
        if ($text === '') {
            error_log('[SBAIG] Could not parse text from OpenAI response: ' . wp_json_encode($data));
            return new WP_Error('sbaig_openai_parse', 'Could not parse content from OpenAI response (see debug.log).');
        }

        $json = $this->extract_json_object($text);
        if (!$json) {
            error_log('[SBAIG] OpenAI did not return JSON-only. Raw: ' . $text);
            return new WP_Error('sbaig_openai_bundle', 'OpenAI did not return valid JSON. Please try again.');
        }

        $bundle = json_decode($json, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($bundle)) {
            error_log('[SBAIG] Failed to decode bundle JSON. Raw: ' . $json);
            return new WP_Error('sbaig_openai_bundle', 'Could not decode SEO bundle JSON (see debug.log).');
        }

        // Light normalization
        if (isset($bundle['meta_title'])) $bundle['meta_title'] = $this->trim_len((string) $bundle['meta_title'], 80);
        if (isset($bundle['meta_description'])) $bundle['meta_description'] = $this->trim_len((string) $bundle['meta_description'], 220);

        return $bundle;
    }

    private function extract_json_object($text) {
        // Find first {...} block (best-effort)
        $start = strpos($text, '{');
        $end   = strrpos($text, '}');
        if ($start === false || $end === false || $end <= $start) return '';
        return substr($text, $start, $end - $start + 1);
    }

    private function trim_len($text, $max) {
        $text = trim($text);
        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($text) > $max) {
                return mb_substr($text, 0, $max);
            }
            return $text;
        }
        return (strlen($text) > $max) ? substr($text, 0, $max) : $text;
    }

    /* =========================
     * Licensing (Lemon Squeezy)
     * ========================= */

    private function get_instance_name(): string {
        $host = wp_parse_url(home_url(), PHP_URL_HOST);
        return is_string($host) && $host ? $host : home_url();
    }

    private function get_or_create_instance_id(): string {
        $id = (string) get_option(self::OPTION_LICENSE_INSTANCE, '');
        if ($id !== '') return $id;
        // Local unique id (used only until Lemon Squeezy returns an instance_id)
        $id = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : md5(home_url() . '|' . time());
        update_option(self::OPTION_LICENSE_INSTANCE, $id);
        return $id;
    }

    private function ls_post(string $endpoint, array $payload) {
        $url = 'https://api.lemonsqueezy.com/v1/licenses/' . ltrim($endpoint, '/');
        $resp = wp_remote_post($url, [
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'timeout' => 20,
            'body' => wp_json_encode($payload),
        ]);
        if (is_wp_error($resp)) return $resp;
        $code = (int) wp_remote_retrieve_response_code($resp);
        $body = (string) wp_remote_retrieve_body($resp);
        $data = json_decode($body, true);
        if ($code < 200 || $code >= 300) {
            $msg = 'HTTP ' . $code;
            if (is_array($data) && !empty($data['error'])) {
                $msg .= ': ' . (is_string($data['error']) ? $data['error'] : wp_json_encode($data['error']));
            }
            return new WP_Error('rankora_ls_http', $msg);
        }
        if (!is_array($data)) {
            return new WP_Error('rankora_ls_json', 'Invalid JSON response from Lemon Squeezy');
        }
        return $data;
    }

    public function is_license_active(bool $force_validate = false): bool {
        return true;
    }

    public function license_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to access this page.', 'sbaig'));
        }

        $key = esc_attr((string) get_option(self::OPTION_LICENSE_KEY, ''));
        $status = $this->is_license_active() ? 'active' : 'inactive';
        $instance_id = esc_html((string) get_option(self::OPTION_LICENSE_INSTANCE, ''));

        $activate_url = esc_url(admin_url('admin-post.php'));

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Rankora – License', 'sbaig') . '</h1>';

        echo '<p>' . esc_html__('Enter your Lemon Squeezy license key to activate Rankora on this site.', 'sbaig') . '</p>';

        echo '<table class="widefat" style="max-width: 820px;">';
        echo '<tbody>';
        echo '<tr><th style="width:220px">' . esc_html__('Status', 'sbaig') . '</th><td><strong>' . esc_html(strtoupper($status)) . '</strong></td></tr>';
        echo '<tr><th>' . esc_html__('Instance ID', 'sbaig') . '</th><td><code>' . $instance_id . '</code></td></tr>';
        echo '</tbody></table>';

        echo '<h2 style="margin-top: 24px;">' . esc_html__('Activate', 'sbaig') . '</h2>';
        echo '<form method="post" action="' . $activate_url . '">';
        echo '<input type="hidden" name="action" value="rankora_activate_license" />';
        wp_nonce_field('rankora_license_action', 'rankora_license_nonce');
        echo '<p><input type="text" name="license_key" value="' . $key . '" style="width: 420px;" placeholder="XXXX-XXXX-XXXX" />';
        echo ' <button class="button button-primary" type="submit">' . esc_html__('Activate License', 'sbaig') . '</button></p>';
        echo '</form>';

        echo '<h2 style="margin-top: 18px;">' . esc_html__('Deactivate', 'sbaig') . '</h2>';
        echo '<form method="post" action="' . $activate_url . '">';
        echo '<input type="hidden" name="action" value="rankora_deactivate_license" />';
        wp_nonce_field('rankora_license_action', 'rankora_license_nonce');
        echo '<p><button class="button" type="submit">' . esc_html__('Deactivate on this site', 'sbaig') . '</button></p>';
        echo '</form>';

        echo '</div>';
    }

    public function handle_activate_license() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        if (empty($_POST['rankora_license_nonce']) || !wp_verify_nonce($_POST['rankora_license_nonce'], 'rankora_license_action')) {
            wp_die('Invalid nonce');
        }

        $key = isset($_POST['license_key']) ? sanitize_text_field(wp_unslash($_POST['license_key'])) : '';
        $key = preg_replace('/\s+/', '', $key);
        if ($key === '') {
            wp_safe_redirect(admin_url('tools.php?page=rankora-license'));
            exit;
        }

        $res = $this->ls_post('activate', [
            'license_key' => $key,
            'instance_name' => $this->get_instance_name(),
        ]);

        if (is_wp_error($res)) {
            update_option(self::OPTION_LICENSE_KEY, $key);
            update_option(self::OPTION_LICENSE_STATUS, 'inactive');
            wp_safe_redirect(add_query_arg(['page'=>'rankora-license','rankora_ls'=>'error','msg'=>rawurlencode($res->get_error_message())], admin_url('tools.php')));
            exit;
        }

        $activated = false;
        if (isset($res['activated'])) $activated = (bool) $res['activated'];
        if (isset($res['license_key']['status']) && is_string($res['license_key']['status'])) {
            $activated = in_array($res['license_key']['status'], ['active', 'valid'], true);
        }

        update_option(self::OPTION_LICENSE_KEY, $key);
        update_option(self::OPTION_LICENSE_STATUS, $activated ? 'active' : 'inactive');
        update_option(self::OPTION_LICENSE_LASTCHK, time());

        // Lemon Squeezy often returns instance_id; store if present
        if (!empty($res['instance_id']) && is_string($res['instance_id'])) {
            update_option(self::OPTION_LICENSE_INSTANCE, $res['instance_id']);
        } else {
            $this->get_or_create_instance_id();
        }

        $q = ['page'=>'rankora-license','rankora_ls'=> $activated ? 'success' : 'error'];
        if (!$activated) $q['msg'] = rawurlencode('Activation failed. Check your license key.');
        wp_safe_redirect(add_query_arg($q, admin_url('tools.php')));
        exit;
    }

    public function handle_deactivate_license() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        if (empty($_POST['rankora_license_nonce']) || !wp_verify_nonce($_POST['rankora_license_nonce'], 'rankora_license_action')) {
            wp_die('Invalid nonce');
        }

        $key = (string) get_option(self::OPTION_LICENSE_KEY, '');
        $instance_id = (string) get_option(self::OPTION_LICENSE_INSTANCE, '');

        if ($key !== '' && $instance_id !== '') {
            $this->ls_post('deactivate', [
                'license_key' => $key,
                'instance_id' => $instance_id,
            ]);
        }

        update_option(self::OPTION_LICENSE_STATUS, 'inactive');
        update_option(self::OPTION_LICENSE_LASTCHK, time());
        wp_safe_redirect(add_query_arg(['page'=>'rankora-license','rankora_ls'=>'success','msg'=>rawurlencode('Deactivated.')], admin_url('tools.php')));
        exit;
    }

    public function admin_notices_licensing() {
        if (!is_admin()) return;
        if (empty($_GET['page']) || $_GET['page'] !== 'rankora-license') return;
        if (empty($_GET['rankora_ls'])) return;

        $type = sanitize_text_field(wp_unslash($_GET['rankora_ls']));
        $msg = !empty($_GET['msg']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['msg']))) : '';

        $class = 'notice notice-info';
        if ($type === 'success') $class = 'notice notice-success';
        if ($type === 'error') $class = 'notice notice-error';

        echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($msg ?: ($type === 'success' ? 'OK' : 'Something went wrong')) . '</p></div>';
    }

    /* =========================
     * Metaboxes
     * ========================= */

    public function add_metaboxes() {
        add_meta_box(
            'sbaig_type',
            esc_html__('Blog Content Type (SBAIG)', 'sbaig'),
            [$this, 'metabox_type_html'],
            'post',
            'side'
        );

        

add_meta_box(
    'sbaig_language',
    esc_html__('Post Language (SBAIG)', 'sbaig'),
    [$this, 'metabox_language_html'],
    'post',
    'side',
    'default'
);
add_meta_box(
            'sbaig_seo',
            esc_html__('SEO (SBAIG)', 'sbaig'),
            [$this, 'metabox_seo_html'],
            'post',
            'normal',
            'high'
        );
    }

    public function metabox_type_html($post) {
        wp_nonce_field(self::NONCE_MB, self::NONCE_MB);

        $value = get_post_meta($post->ID, self::META_CONTENT_TYPE, true);
        if (!$value) $value = 'tofu';

        echo '<p><label for="sbaig_content_type">' . esc_html__('Funnel stage / content type:', 'sbaig') . '</label></p>';
        echo '<select name="' . esc_attr(self::META_CONTENT_TYPE) . '" id="sbaig_content_type" style="width:100%">';
        echo '<option value="tofu" ' . selected($value, 'tofu', false) . '>' . esc_html__('TOFU', 'sbaig') . '</option>';
        echo '<option value="mofu" ' . selected($value, 'mofu', false) . '>' . esc_html__('MOFU', 'sbaig') . '</option>';
        echo '<option value="bofu" ' . selected($value, 'bofu', false) . '>' . esc_html__('BOFU', 'sbaig') . '</option>';
        echo '</select>';
    }

    public function metabox_seo_html($post) {
        wp_nonce_field(self::NONCE_SEO_MB, self::NONCE_SEO_MB);

        $seo_title = get_post_meta($post->ID, self::META_SEO_TITLE, true);
        $seo_desc  = get_post_meta($post->ID, self::META_SEO_DESC, true);
        $focus_kw  = get_post_meta($post->ID, self::META_FOCUS_KW, true);
        $canonical = get_post_meta($post->ID, self::META_CANONICAL, true);
        $og_image  = get_post_meta($post->ID, self::META_OG_IMAGE, true);
        $noindex   = get_post_meta($post->ID, self::META_NOINDEX, true);

        echo '<table class="form-table" role="presentation" style="margin-top:0;">';

        echo '<tr><th style="width:160px;"><label for="sbaig_seo_title">' . esc_html__('Meta Title', 'sbaig') . '</label></th><td>';
        echo '<input id="sbaig_seo_title" type="text" name="' . esc_attr(self::META_SEO_TITLE) . '" value="' . esc_attr($seo_title) . '" style="width:100%;" placeholder="~50–60 chars" />';
        echo '</td></tr>';

        echo '<tr><th><label for="sbaig_seo_desc">' . esc_html__('Meta Description', 'sbaig') . '</label></th><td>';
        echo '<textarea id="sbaig_seo_desc" name="' . esc_attr(self::META_SEO_DESC) . '" rows="3" style="width:100%;" placeholder="~140–155 chars">' . esc_textarea($seo_desc) . '</textarea>';
        echo '</td></tr>';

        echo '<tr><th><label for="sbaig_focus_kw">' . esc_html__('Focus Keyword', 'sbaig') . '</label></th><td>';
        echo '<input id="sbaig_focus_kw" type="text" name="' . esc_attr(self::META_FOCUS_KW) . '" value="' . esc_attr($focus_kw) . '" style="width:100%;" placeholder="e.g. customer onboarding automation" />';
        echo '</td></tr>';

        echo '<tr><th><label for="sbaig_canonical">' . esc_html__('Canonical URL', 'sbaig') . '</label></th><td>';
        echo '<input id="sbaig_canonical" type="url" name="' . esc_attr(self::META_CANONICAL) . '" value="' . esc_attr($canonical) . '" style="width:100%;" placeholder="' . esc_attr(get_permalink($post)) . '" />';
        echo '<p class="description">' . esc_html__('Leave empty to use the post permalink.', 'sbaig') . '</p>';
        echo '</td></tr>';

        echo '<tr><th><label for="sbaig_og_image">' . esc_html__('Open Graph Image URL', 'sbaig') . '</label></th><td>';
        echo '<input id="sbaig_og_image" type="url" name="' . esc_attr(self::META_OG_IMAGE) . '" value="' . esc_attr($og_image) . '" style="width:100%;" placeholder="https://example.com/image.jpg" />';
        echo '<p class="description">' . esc_html__('If empty, we will use Featured Image, then default OG image from settings.', 'sbaig') . '</p>';
        echo '</td></tr>';

        echo '<tr><th>' . esc_html__('Indexing', 'sbaig') . '</th><td>';
        echo '<label><input type="checkbox" name="' . esc_attr(self::META_NOINDEX) . '" value="1" ' . checked('1', $noindex, false) . ' /> ' . esc_html__('Noindex this post', 'sbaig') . '</label>';
        echo '</td></tr>';

        echo '</table>';

        $faq_json = get_post_meta($post->ID, self::META_FAQ_JSON, true);
        if (!empty($faq_json)) {
            echo '<p><strong>' . esc_html__('FAQ schema detected', 'sbaig') . '</strong></p>';
            echo '<p class="description">' . esc_html__('This post has FAQ data saved and will output FAQPage JSON-LD (if enabled).', 'sbaig') . '</p>';
        }
    }

    public function save_metaboxes($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if ($post->post_type !== 'post') return;
        if (!current_user_can('edit_post', $post_id)) return;

        // Type metabox
        if (isset($_POST[self::NONCE_MB]) && wp_verify_nonce($_POST[self::NONCE_MB], self::NONCE_MB)) {
            if (isset($_POST[self::META_CONTENT_TYPE])) {
                $value = sanitize_text_field($_POST[self::META_CONTENT_TYPE]);
                if (!in_array($value, ['tofu', 'mofu', 'bofu'], true)) $value = 'tofu';
                update_post_meta($post_id, self::META_CONTENT_TYPE, $value);
            }

// Post language
if (isset($_POST[self::META_POST_LANGUAGE])) {
    $lang = sanitize_text_field($_POST[self::META_POST_LANGUAGE]);

    // Allow empty (default) or valid locale string
    if ($lang === '') {
        delete_post_meta($post_id, self::META_POST_LANGUAGE);
    } else {
        // Basic validation: locale usually like "en_US" or "pt_BR" or "pt-BR"
        if (!preg_match('/^[a-z]{2,3}([_-][A-Za-z0-9]{2,8})+$/', $lang)) {
            $lang = '';
        }

        if ($lang === '') {
            delete_post_meta($post_id, self::META_POST_LANGUAGE);
        } else {
            update_post_meta($post_id, self::META_POST_LANGUAGE, $lang);
        }
    }
}

        }

        // SEO metabox
        if (isset($_POST[self::NONCE_SEO_MB]) && wp_verify_nonce($_POST[self::NONCE_SEO_MB], self::NONCE_SEO_MB)) {
            $seo_title = isset($_POST[self::META_SEO_TITLE]) ? sanitize_text_field($_POST[self::META_SEO_TITLE]) : '';
            $seo_desc  = isset($_POST[self::META_SEO_DESC]) ? sanitize_textarea_field($_POST[self::META_SEO_DESC]) : '';
            $focus_kw  = isset($_POST[self::META_FOCUS_KW]) ? sanitize_text_field($_POST[self::META_FOCUS_KW]) : '';
            $canonical = isset($_POST[self::META_CANONICAL]) ? esc_url_raw($_POST[self::META_CANONICAL]) : '';
            $og_image  = isset($_POST[self::META_OG_IMAGE]) ? esc_url_raw($_POST[self::META_OG_IMAGE]) : '';
            $noindex   = !empty($_POST[self::META_NOINDEX]) ? '1' : '0';

            $this->update_or_delete_meta($post_id, self::META_SEO_TITLE, $seo_title);
            $this->update_or_delete_meta($post_id, self::META_SEO_DESC,  $seo_desc);
            $this->update_or_delete_meta($post_id, self::META_FOCUS_KW,  $focus_kw);
            $this->update_or_delete_meta($post_id, self::META_CANONICAL, $canonical);
            $this->update_or_delete_meta($post_id, self::META_OG_IMAGE,  $og_image);

            if ($noindex === '1') update_post_meta($post_id, self::META_NOINDEX, '1');
            else delete_post_meta($post_id, self::META_NOINDEX);

            // If excerpt is empty, prefer meta description
            if (!empty($seo_desc) && empty($post->post_excerpt)) {
                remove_action('save_post', [$this, 'save_metaboxes'], 10);
                wp_update_post([
                    'ID' => $post_id,
                    'post_excerpt' => $seo_desc,
                ]);
                add_action('save_post', [$this, 'save_metaboxes'], 10, 2);
            }
        }
    }

    private function update_or_delete_meta($post_id, $key, $value) {
        if ($value === '' || $value === null) {
            delete_post_meta($post_id, $key);
        } else {
            update_post_meta($post_id, $key, $value);
        }
    }

    /* =========================
     * Front-end SEO output
     * ========================= */

    public function output_seo_meta() {
        if (!(bool) get_option(self::OPTION_ENABLE_SEO, true)) return;
        if (!is_singular('post')) return;

        global $post;
        if (!$post instanceof WP_Post) return;

        $post_id = $post->ID;

        $noindex = get_post_meta($post_id, self::META_NOINDEX, true) === '1';
        $seo_title = get_post_meta($post_id, self::META_SEO_TITLE, true);
        $seo_desc  = get_post_meta($post_id, self::META_SEO_DESC, true);
        $canonical = get_post_meta($post_id, self::META_CANONICAL, true);

        $title = $seo_title ? $seo_title : single_post_title('', false);
        $desc  = $seo_desc ? $seo_desc : ( $post->post_excerpt ? $post->post_excerpt : wp_trim_words(wp_strip_all_tags($post->post_content), 26, '…') );

        $canonical_url = $canonical ? $canonical : get_permalink($post);

        $og_image = $this->resolve_og_image_url($post_id);

        // Basic
        if ($noindex) {
            echo "<meta name=\"robots\" content=\"noindex,follow\" />\n";
        } else {
            echo "<meta name=\"robots\" content=\"index,follow\" />\n";
        }

        echo '<link rel="canonical" href="' . esc_url($canonical_url) . "\" />\n";
        echo '<meta name="description" content="' . esc_attr($this->trim_len($desc, 240)) . "\" />\n";

        // Open Graph
        echo '<meta property="og:type" content="article" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($this->trim_len($title, 120)) . "\" />\n";
        echo '<meta property="og:description" content="' . esc_attr($this->trim_len($desc, 240)) . "\" />\n";
        echo '<meta property="og:url" content="' . esc_url($canonical_url) . "\" />\n";
        echo '<meta property="og:site_name" content="' . esc_attr(get_bloginfo('name')) . "\" />\n";
        if (!empty($og_image)) {
            echo '<meta property="og:image" content="' . esc_url($og_image) . "\" />\n";
        }

        // Twitter Cards
        echo '<meta name="twitter:card" content="' . ( !empty($og_image) ? 'summary_large_image' : 'summary' ) . "\" />\n";
        echo '<meta name="twitter:title" content="' . esc_attr($this->trim_len($title, 120)) . "\" />\n";
        echo '<meta name="twitter:description" content="' . esc_attr($this->trim_len($desc, 240)) . "\" />\n";
        if (!empty($og_image)) {
            echo '<meta name="twitter:image" content="' . esc_url($og_image) . "\" />\n";
        }

        // JSON-LD schema
        if ((bool) get_option(self::OPTION_ENABLE_SCHEMA, true)) {
            $this->output_schema_json_ld($post, $title, $desc, $canonical_url, $og_image);
        }
    }

    private function resolve_og_image_url($post_id) {
        $custom = get_post_meta($post_id, self::META_OG_IMAGE, true);
        if (!empty($custom)) return $custom;

        if (has_post_thumbnail($post_id)) {
            $url = get_the_post_thumbnail_url($post_id, 'full');
            if ($url) return $url;
        }

        $default = get_option(self::OPTION_DEFAULT_OG_IMAGE, '');
        return $default ? $default : '';
    }

    private function output_schema_json_ld($post, $title, $desc, $canonical_url, $og_image) {
        $post_id = $post->ID;

        $author_name = get_the_author_meta('display_name', $post->post_author);
        $published = get_the_date('c', $post);
        $modified  = get_the_modified_date('c', $post);

        $publisher = [
            '@type' => 'Organization',
            'name'  => get_bloginfo('name'),
        ];

        // Try to attach site icon as logo (optional)
        $site_icon_id = get_option('site_icon');
        if ($site_icon_id) {
            $logo_url = wp_get_attachment_image_url($site_icon_id, 'full');
            if ($logo_url) {
                $publisher['logo'] = [
                    '@type' => 'ImageObject',
                    'url'   => $logo_url,
                ];
            }
        }

        $schema = [
            '@context' => 'https://schema.org',
            '@type'    => 'Article',
            'headline' => $this->trim_len($title, 120),
            'description' => $this->trim_len($desc, 240),
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id'   => $canonical_url,
            ],
            'datePublished' => $published,
            'dateModified'  => $modified,
            'author' => [
                '@type' => 'Person',
                'name'  => $author_name ? $author_name : '',
            ],
            'publisher' => $publisher,
        ];

        if (!empty($og_image)) {
            $schema['image'] = [$og_image];
        }

        // Optional focus keyword as keywords
        $focus_kw = get_post_meta($post_id, self::META_FOCUS_KW, true);
        if (!empty($focus_kw)) {
            $schema['keywords'] = $focus_kw;
        }

        echo "<script type=\"application/ld+json\">" . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";

        // Optional FAQ schema
        $faq_json = get_post_meta($post_id, self::META_FAQ_JSON, true);
        if (!empty($faq_json)) {
            $faq = json_decode($faq_json, true);
            if (is_array($faq) && !empty($faq)) {
                $faq_schema = [
                    '@context' => 'https://schema.org',
                    '@type' => 'FAQPage',
                    'mainEntity' => [],
                ];
                foreach ($faq as $row) {
                    if (!is_array($row)) continue;
                    $q = isset($row['q']) ? trim((string)$row['q']) : '';
                    $a = isset($row['a']) ? trim((string)$row['a']) : '';
                    if ($q === '' || $a === '') continue;
                    $faq_schema['mainEntity'][] = [
                        '@type' => 'Question',
                        'name'  => $this->trim_len($q, 200),
                        'acceptedAnswer' => [
                            '@type' => 'Answer',
                            'text'  => $a,
                        ],
                    ];
                }
                if (!empty($faq_schema['mainEntity'])) {
                    echo "<script type=\"application/ld+json\">" . wp_json_encode($faq_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
                }
            }
        }
    }

    /* =========================
     * XML Sitemap
     * ========================= */

    public function register_sitemap_route() {
        if (!(bool) get_option(self::OPTION_ENABLE_SITEMAP, true)) {
            // Still register rewrite for existing installs; rendering checks option.
        }

        add_rewrite_rule('^sbaig-sitemap\.xml$', 'index.php?' . self::SITEMAP_QUERY_VAR . '=1', 'top');
    }

    public function register_query_vars($vars) {
        $vars[] = self::SITEMAP_QUERY_VAR;
        return $vars;
    }

    public function maybe_render_sitemap() {
        $is_sitemap = get_query_var(self::SITEMAP_QUERY_VAR);
        if (!$is_sitemap) return;

        if (!(bool) get_option(self::OPTION_ENABLE_SITEMAP, true)) {
            status_header(404);
            exit;
        }

        header('Content-Type: application/xml; charset=UTF-8');

        $posts = get_posts([
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 1000,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'no_found_rows'  => true,
        ]);

        echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        echo "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";

        foreach ($posts as $p) {
            $noindex = get_post_meta($p->ID, self::META_NOINDEX, true) === '1';
            if ($noindex) continue;

            $loc = get_permalink($p);
            $lastmod = get_the_modified_date('c', $p);

            echo "<url>\n";
            echo "  <loc>" . esc_url($loc) . "</loc>\n";
            echo "  <lastmod>" . esc_html($lastmod) . "</lastmod>\n";
            echo "  <changefreq>weekly</changefreq>\n";
            echo "  <priority>0.7</priority>\n";
            echo "</url>\n";
        }

        echo "</urlset>";
        exit;
    }
}

new Rankora();
